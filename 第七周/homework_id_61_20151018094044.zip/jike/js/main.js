define(function(require, exports, module) {
    require('jquery');  //普通jquery库
    //幻灯片
    var slide=require('module/slide');    
    //左栏导航
    var bar =require('module/bar');
    //普通效果    
    var normal=require('module/normal');
    //底部切换
    var card=require('module/card');
    //课程切换
    var lesson=require('module/lesson');

});
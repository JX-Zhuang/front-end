var timeoutid; //延时
$(document).ready(function() {
    $('#tablefirst li').each(function(index) { //each()遍历每个li标签
        var liNode = $(this);
        liNode.mouseover(function() {
            timeoutid = setTimeout(function() {
                $('div.content').removeClass('content');
                $('#tablefirst li.tabin').removeClass('tabin');
                $('div').eq(index).addClass('content');
                liNode.addClass('tabin');
            }, 300)
        }).mouseout(function() {
            clearTimeout(timeoutid)

        })
    })

    $('#realcontent').load("http://www.baidu.com");

})
